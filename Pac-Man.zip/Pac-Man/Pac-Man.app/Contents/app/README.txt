
How to play:
Use arrow keys or WASD to move.
Avoid the ghosts and eat pellets 
If you encounter an error, bug, or issue, e-mail bugs@getpacman.gq

Acknowledgements:
Thanks to freepacman.org, Hatch Coding, convertico.com, and The Processing Foundation

Copyright:
Fruit sprites and sounds are taken from freepacman.org
Source code produced by Langdon Staab 2018 - 2023 with help from Peter Petrone

www.getpacman.gq